#pragma once

struct WindowConfiguration
{
	int windowWidth = 800;
	int windowHeight = 600;
	bool fullscreen = false;
};