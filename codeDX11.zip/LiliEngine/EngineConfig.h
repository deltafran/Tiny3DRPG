#pragma once

// Support renderer
#define LILI_DIRECT3D11 0
#define LILI_VULKAN     1

// Support feature
#define LILI_ENABLE_3D  1