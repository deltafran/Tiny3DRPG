#include "stdafx.h"
#include "StringUtils.h"

namespace Str
{

} // namespace Str