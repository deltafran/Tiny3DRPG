#include "stdafx.h"
#include "Globals.h"