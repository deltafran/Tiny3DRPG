#pragma once

struct RendererConfiguration
{
	bool vsync = false;
};