#pragma once

class PlatformSystem final
{
public:

};