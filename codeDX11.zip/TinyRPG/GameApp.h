#pragma once

#if LILI_DIRECT3D11

class GameApp
{
public:
	bool Init();

	void Update();

	void Draw();

	void Close();

private:
	Camera m_camera;
	Model m_model;
	GraphicShaders m_shaders;
	Light m_light;
};

#endif