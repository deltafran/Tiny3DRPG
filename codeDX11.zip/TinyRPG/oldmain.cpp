﻿#include "stdafx.h"
#include "GameApp.h"

#pragma comment(lib, "LiliEngine.lib")
#pragma comment(lib, "3rdparty.lib")

int oldmain([[maybe_unused]] int argc, [[maybe_unused]] char** argv)
{
	Configuration config;
	config.logFileName = "TinyRPG.log";

	Application& app = Globals::Application();
	GameApp game;

	if (app.Init(config) && game.Init())
	{
		while (!app.IsQuit())
		{
			app.Update();
			game.Update();
			app.BeginFrame();
			game.Draw();
			app.EndFrame();
		}
		game.Close();
	}

	return 0;
}